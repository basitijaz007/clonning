# 🎙️ Voice Cloning Script

Free, offline voice cloning using Coqui XTTS-v2. Clone any voice with just 6-60 seconds of reference audio.

## ⚡ Quick Start

```bash
# Create virtual environment with Python 3.11 (required)
uv venv --python 3.11
.venv\Scripts\activate

# Install dependencies
uv pip install coqui-tts torch torchaudio

# Clone a voice
python voice_clone.py --reference adam_sample.wav --text "Hello, this is my cloned voice!" --output output.wav
```

## 📦 Installation

### Prerequisites
- **Python 3.10 - 3.13** (REQUIRED - Python 3.14+ not supported)
- 4GB+ RAM (8GB recommended)
- GPU with CUDA optional (faster) but CPU works
- [uv](https://github.com/astral-sh/uv) package manager (recommended)

### Install with uv (Recommended)
```bash
cd d:\python\clonning

# Create virtual environment with compatible Python
uv venv --python 3.11
.venv\Scripts\activate

# Install dependencies
uv pip install coqui-tts torch torchaudio
```

> **Note:** First run downloads the XTTS-v2 model (~1.8GB).

## 🎯 Usage

### Basic Usage
```bash
python voice_clone.py --reference "adam_sample.wav" --text "Your text here" --output "output.wav"
```

### From Text File (for long scripts)
```bash
python voice_clone.py --reference "adam_sample.wav" --text_file "script.txt" --output "narration.wav"
```

### Different Languages
```bash
python voice_clone.py --reference "adam.wav" --text "Bonjour le monde" --output "french.wav" --language fr
```

Supported languages: `en`, `es`, `fr`, `de`, `it`, `pt`, `pl`, `tr`, `ru`, `nl`, `cs`, `ar`, `zh-cn`, `ja`, `hu`, `ko`

## 🎤 Preparing Reference Audio

For best results with your "Adam" voice sample:

1. **Duration:** 6-60 seconds (1 minute is ideal)
2. **Quality:** Clear speech, minimal background noise
3. **Format:** WAV, MP3, FLAC, OGG, or M4A
4. **Content:** Natural speaking (not singing or whispering)

### Tips for Recording/Extracting Adam Voice
- Record from ElevenLabs sample or find a clean YouTube clip
- Use [Audacity](https://www.audacityteam.org/) to trim and clean audio
- Remove background music/noise if possible

## 📁 Project Structure

```
clonning/
├── voice_clone.py      # Main script
├── requirements.txt    # Dependencies
├── README.md          # This file
├── adam_sample.wav    # Your reference audio (add this)
└── output.wav         # Generated output
```

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| CUDA out of memory | Use shorter text chunks or run on CPU |
| Poor voice quality | Use clearer reference audio (30+ seconds) |
| Model download fails | Check internet connection, retry |
| Import errors | Ensure Python 3.9-3.11, reinstall TTS |

## 📄 License

This project uses Coqui TTS (MPL-2.0 License). For personal and research use.
